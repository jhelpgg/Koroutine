package fr.jhelp.models.shared

enum class Screen
{
    UNDEFINED,
    GREETINGS,
    SECOND
}