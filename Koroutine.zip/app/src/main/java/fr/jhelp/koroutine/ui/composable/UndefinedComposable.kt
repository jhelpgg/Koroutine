package fr.jhelp.koroutine.ui.composable

import androidx.compose.runtime.Composable

object UndefinedComposable
{
    @Composable
     fun Draw()
    {
        // Nothing to do
    }
}