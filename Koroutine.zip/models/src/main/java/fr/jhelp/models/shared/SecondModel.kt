package fr.jhelp.models.shared

interface SecondModel
{
    fun action()
    fun back()
}